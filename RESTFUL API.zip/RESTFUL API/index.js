const express = require("express");
const app = express();
const port = 8080;

const path = require("path");
const { v4: uuidv4 } = require("uuid");
const methodOverride = require("method-override");

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride("_method"));
app.use(express.static(path.join(__dirname, "public")));

// View Engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Data
let posts = [
    {
        id: uuidv4(),
        username: "Gurparshad Singh",
        content: "I love coding",
    },
    {
        id: uuidv4(),
        username: "Adarshpreet Singh",
        content: "I love driving",
    },
    {
        id: uuidv4(),
        username: "Sejahdeep Singh",
        content: "I love cricket",
    },
];

// ================= ROUTES =================

// Show all posts
app.get("/posts", (req, res) => {
    res.render("index", { posts });
});

// New post form
app.get("/posts/new", (req, res) => {
    res.render("new");
});

// Create post
app.post("/posts", (req, res) => {
    const { username, content } = req.body;
    posts.push({
        id: uuidv4(),
        username,
        content,
    });

    res.redirect("/posts");
});

// ⚠️ IMPORTANT: EDIT route BEFORE :id route
app.get("/posts/:id/edit", (req, res) => {
    const { id } = req.params;
    const post = posts.find((p) => p.id === id);

    if (!post) {
        return res.send("Post not found 🚫");
    }

    res.render("edit", { post });
});

// Show single post
app.get("/posts/:id", (req, res) => {
    const { id } = req.params;
    const post = posts.find((p) => p.id === id);

    if (!post) {
        return res.send("Post not found 🚫");
    }

    res.render("show", { post });
});

// Update post
app.patch("/posts/:id", (req, res) => {
    const { id } = req.params;
    const { content } = req.body;

    const post = posts.find((p) => p.id === id);

    if (!post) {
        return res.send("Post not found 🚫");
    }

    post.content = content;

    res.redirect("/posts");
});

// Delete post
app.delete("/posts/:id", (req, res) => {
    const { id } = req.params;

    posts = posts.filter((p) => p.id !== id);

    res.redirect("/posts");
});

// Server
app.listen(port, () => {
    console.log(`🚀 Server running on port ${port}`);
});